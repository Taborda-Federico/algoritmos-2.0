bool pedir_booleano(char name){
    int m;
    printf("almacena un valor en %c (SOLO DE TIPO BOOL): ", name);
    scanf("%d", &m);
    return m;
}